//
//  InvaderAWSmain.swift
//  InvaderAWS
//
//  Created by urasehiroki on 2018/12/14.
//  Copyright © 2018年 urasehiroki. All rights reserved.
//


// このファイルは、メイン画面とアクティビティ画面を管理します

import UIKit

class ViewController: UIViewController {
    
    @IBAction func exitToMain(segue: UIStoryboardSegue){
        print("exit to top")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
}
