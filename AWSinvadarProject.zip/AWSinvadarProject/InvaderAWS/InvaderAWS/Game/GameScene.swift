//
//  GameScene.swift
//  InvaderAWS
//
//  Created by urasehiroki on 2018/12/11.
//  Copyright © 2018年 urasehiroki. All rights reserved.
//

// このファイルに、ゲーム内に登場するクラスを実装していきます
import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    /* GameSceneクラス
    // インベーダーゲームのゲーム部分を進行、管理してくれるクラス
    //
    */
    
    //変数tankにクラス戦車を生成する
    let tank = Tank()
    let ufo = Ufo()
    // UFO用
    enum UfoMovementDirection {
        case right
        case left
        case none
    }
    // 移動方向初期値
    var ufoMovementDirection: UfoMovementDirection = .left
    // 最終移動
    var timeOfLastMove: CFTimeInterval = 0.0
    // 移動速度
    let timePerMove: CFTimeInterval = 1.0
    // UFO用

    
    override func didMove(to view: SKView) {
        /* GameSceneクラス
        // このメソッドは、ゲーム部分が立ち上がると起動します
        // そこで、立ち上がったときに戦車、インベーダー、防御壁をし出現させるプログラムを実装する
        */
        
        backgroundColor = SKColor.black
        //戦車を出現させる
        self.tank.position = CGPoint(x: self.size.width / 2, y: 100)
        addChild(tank)
        
        //インベーダーを出現させる
        
        //防護壁を出現させる
        
        //テストUFO出現　動きチェック用
        //     ランダムで出現方法を決める
        //     右から出現
        ufo.position = CGPoint(x: size.width, y: size.height - 50)
        //     左から出現
        //        ufo.position = CGPoint(x: 0, y: size.height - 50)
        
        addChild(ufo)
    }
    
    override func update(_ currentTime: TimeInterval) {
        //ufoがいるか判定する
        //ufoがいなかったら、出現させるかランダムで決定する
        //ufoを出現させて一定時間動かす
        self.ufo.move()
    }
}

class Tank: SKSpriteNode{
    
    let image_name: String = "ship"
    
    init(){
        let texture = SKTexture(imageNamed: image_name)
        super.init(texture: texture, color: UIColor.white, size: texture.size())
    }
    
    //エラー処理のためSKSpriteNode必要
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func move(direction: CGFloat){
        let actionMove = SKAction.move(to: CGPoint(x: direction, y: self.position.y), duration: TimeInterval(CGFloat(2.0)))
        self.run(actionMove, withKey: "moving")
    }
    
    //動きを止めるためのメソッドを実装しました
    func stop(){
        if let action = self.action(forKey: "moving") {
            action.speed = 0
        }
    }
    //戦車のミサイルを打つ
    func shoot(){
        print("hello")
    }
    
}

class Invader: SKSpriteNode{
    
    // 呉より
    var contentCreated = false
    var invaderMovementDirection: InvaderMovementDirection = .right
    
    enum InvaderType {  // InvaderType
        case a
        case b
        case c
        
        static var size: CGSize {
            return CGSize(width: 24, height: 16)
        }
        
        static var name: String {
            return "invader"
        }
    }
    
    // invaderMovement
    enum InvaderMovementDirection {
        case right
        case left
        case downThenRight
        case downThenLeft
        case none
    }
    
    // invaderColor
    func makeInvader(ofType invaderType: InvaderType) -> SKNode {
        var invaderColor: SKColor
        
        switch(invaderType) {
        case .a:
            invaderColor = SKColor.red
        case .b:
            invaderColor = SKColor.green
        case .c:
            invaderColor = SKColor.blue
        }
        
        let invader = SKSpriteNode(color: invaderColor, size:InvaderType.size)
        invader.name = InvaderType.name
        
        return invader
    }
    
    let kInvaderGridSpacing = CGSize(width: 12, height: 12)
    let kInvaderRowCount = 6
    let kInvaderColCount = 6
    
    func setupInvaders() {
        let baseOrigin = CGPoint(x: size.width / 3, y: size.height / 2)
        for row in 0..<kInvaderRowCount {
            var invaderType: InvaderType
            
            if row % 3 == 0 {
                invaderType = .a
            } else if row % 3 == 1 {
                invaderType = .b
            } else {
                invaderType = .c
            }
            
            let invaderPositionY = CGFloat(row) * (InvaderType.size.height * 2) + baseOrigin.y
            var invaderPosition = CGPoint(x: baseOrigin.x, y: invaderPositionY)
            
            for _ in 1..<kInvaderColCount {
                let invader = makeInvader(ofType: invaderType)
                invader.position = invaderPosition
                
                addChild(invader)
                
                invaderPosition = CGPoint(x: invaderPosition.x + InvaderType.size.width + kInvaderGridSpacing.width, y: invaderPositionY)
            }
        }
    }
}



class Ufo: SKSpriteNode{
    //後にUFOに変更　今は戦車で代用
    let image_name: String = "ship"
    
    init(){
        let texture = SKTexture(imageNamed: image_name)
        super.init(texture: texture, color: UIColor.white, size: texture.size())
    }
    
    //エラー処理のためSKSpriteNode必要
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func move(){
        //もし左のはしについたら右方向に移動する
        //もし右のはしについたら左の方向に移動する
        let actionMove = SKAction.move(to: CGPoint(x: self.position.x - 10, y: self.position.y), duration: TimeInterval(CGFloat(2.0)))
        
        self.run(actionMove, withKey: "moving")
        
        //時間がある程度経過していたら、消える
    }
}
class DefenseWall{
    
}

class TankMissle: SKSpriteNode{
    ///////////////////////////////////////////////////////////////////
    let image_name: String = "bullet"
    
    init(){
        let texture = SKTexture(imageNamed: image_name)
        super.init(texture: texture, color: UIColor.white, size: texture.size())
        
    }
    
    //エラー処理のためSKSpriteNode必要
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //上まで行って端で消える
    func move(direction: CGFloat){
        let actionMove = SKAction.move(to: CGPoint(x: self.position.x, y: size.hight+20 ), duration: TimeInterval(CGFloat(2.0)))
        //勝手にすすんでほしい
        self.run(actionMove, withKey: "moving")
    }
}

class DefenseWallMissle: SKSpriteNode{
    
}

class InvaderMissle: SKSpriteNode{
    
}

class Item{
    
}
