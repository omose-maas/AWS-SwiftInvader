//
//  GameScene.swift
//  InvaderAWS
//
//  Created by urasehiroki on 2018/12/11.
//  Copyright © 2018年 urasehiroki. All rights reserved.
//

// このファイルに、ゲーム内に登場するクラスを実装していきます
import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    /* GameSceneクラス
    // インベーダーゲームのゲーム部分を進行、管理してくれるクラス
    //
    */
    
    let tank = Tank()
    
    override func didMove(to view: SKView) {
        /* GameSceneクラス
        // このメソッドは、ゲーム部分が立ち上がると起動します
        // そこで、立ち上がったときに戦車、インベーダー、防御壁をし出現させるプログラムを実装する
        */
        
        backgroundColor = SKColor.black
        //戦車を出現させる
        tank.position = CGPoint(x: size.width / 2, y: 100)
        addChild(tank)
        
        //インベーダーを出現させる
        
        //防護壁を出現させる
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
    }
}

class Tank: SKSpriteNode{
    
    let image_name: String = "ship"
    
    init(){
        let texture = SKTexture(imageNamed: image_name)
        super.init(texture: texture, color: UIColor.white, size: texture.size())
    }
    
    //エラー処理のためSKSpriteNode必要
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func move(direction: CGFloat){
        let actionMove = SKAction.move(to: CGPoint(x: direction, y: self.position.y), duration: TimeInterval(CGFloat(2.0)))
        self.run(actionMove, withKey: "moving")
    }
    
    func stop(){
        if let action = self.action(forKey: "moving") {
            action.speed = 0
        }
    }

}

class Invader: SKSpriteNode{
    
}

class Ufo: SKSpriteNode{
    
}

class DefenseWall{
    
}

class Missle: SKSpriteNode{
    
}

class DefenseWallMissle: SKSpriteNode{
    
}

class InvaderMissle: SKSpriteNode{
    
}

class Item{
    
}
