//
//  GameScene.swift
//  InvaderAWS
//
//  Created by urasehiroki on 2018/12/11.
//  Copyright © 2018年 urasehiroki. All rights reserved.
//

// このファイルに、ゲーム内に登場するクラスを実装していきます

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    /* GameSceneクラス
    // インベーダーゲームのゲーム部分を進行、管理してくれるクラス
    //
    */
    
//    var player:SKSpriteNode
    
    override func didMove(to view: SKView) {
        /* GameSceneクラス
        // このメソッドは、ゲーム部分が立ち上がると起動します
        // そこで、立ち上がったときに戦車、インベーダー、防御壁をし出現させます
        */
        
        //戦車を出現させる
        
        //インベーダーを出現させる
        
        //防護壁を出現させる
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
    }
}

class Tank: SKSpriteNode{
    
}

class Invader: SKSpriteNode{
    
}

class Ufo: SKSpriteNode{
    
}

class DefenseWall{
    
}

class Missle: SKSpriteNode{
    
}

class DefenseWallMissle: SKSpriteNode{
    
}

class InvaderMissle: SKSpriteNode{
    
}

class Item{
    
}
