//
//  GameViewController.swift
//  InvaderAWS
//
//  Created by urasehiroki on 2018/12/11.
//  Copyright © 2018年 urasehiroki. All rights reserved.
//

// このファイルは、ゲーム画面を管理します

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    
    var scene: GameScene!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //新しいゲームシーンクラスを生成する
        self.scene = GameScene(size: view.bounds.size)
        let skView = view as! SKView
        skView.ignoresSiblingOrder = true
        self.scene.scaleMode = .resizeFill
        skView.presentScene(scene)
        
    }
    
    @IBAction func dissmiss(_ sender: Any) {
         dismiss(animated: true, completion: nil)
    }

    @IBAction func leftButtonDown(_ sender: Any) {
        self.scene.tank.move(direction: CGFloat(0))
    }
    
    @IBAction func leftButtonUp(_ sender: Any) {
         self.scene.tank.stop()
    }
    
    @IBAction func rightButton(_ sender: Any) {
        self.scene.tank.move(direction: self.scene.size.width)
    }
    @IBAction func rightButtonUp(_ sender: Any) {
        self.scene.tank.stop()
    }
    
    
    
    @IBAction func fireButton(_ sender: Any) {
        self.scene.tank.shoot()
    }
    

    override var shouldAutorotate: Bool {
        return true
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
