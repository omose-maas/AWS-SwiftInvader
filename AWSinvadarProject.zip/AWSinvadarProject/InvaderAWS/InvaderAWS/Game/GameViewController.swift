//
//  GameViewController.swift
//  InvaderAWS
//
//  Created by urasehiroki on 2018/12/11.
//  Copyright © 2018年 urasehiroki. All rights reserved.
//

// このファイルは、ゲーム画面を管理します

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let scene = GameScene(size: view.bounds.size)
        let skView = view as! SKView
        skView.ignoresSiblingOrder = true
        scene.scaleMode = .resizeFill
        skView.presentScene(scene)
        
    }
    
    @IBAction func dissmiss(_ sender: Any) {
         dismiss(animated: true, completion: nil)
    }
    
    @IBAction func leftButton(_ sender: Any) {
    }
    
    @IBAction func rightButton(_ sender: Any) {
    }
    
    @IBAction func fireButon(_ sender: Any) {
    }
    

    override var shouldAutorotate: Bool {
        return true
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
